import adaboost
from numpy import *


# dataArr,labelArr=adaboost.loadSimpData()
# classifierArr=adaboost.adaBoostTrainDS(dataArr,labelArr,30)
# print(adaboost.adaClassify([[5,5],[0,0]],classifierArr))
datArr,labelArr=adaboost.loadDataSet("./Data/horseColicTraining.txt")
classifierArray=adaboost.adaBoostTrainDS(datArr,labelArr,10)
testArr,testLabelArr=adaboost.loadDataSet("./Data/horseColicTest.txt")
prediction10=adaboost.adaClassify(testArr,classifierArray)
errArr=mat(ones((67,1)))
print(errArr[prediction10!=mat(testLabelArr).T].sum())