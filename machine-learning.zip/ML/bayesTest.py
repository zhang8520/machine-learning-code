import bayes

# listOfPosts,listClasses=bayes.loadDataSet()
# myVocabList=bayes.createVocabList(listOfPosts)
# trainMat=[]
# for postinDoc in listOfPosts:
#     trainMat.append(bayes.setOfWord2Vec(myVocabList,postinDoc))
# p0V,p1V,pAb=bayes.trainNB0(trainMat,listClasses)
bayes.spamTest()